#ifndef _CALLBACK_H_
#define _CALLBACK_H_

void KeyListener(int key,int event);
void CharListener(char key);
void MouseListener(int mx,int my,int button,int event);

#endif
